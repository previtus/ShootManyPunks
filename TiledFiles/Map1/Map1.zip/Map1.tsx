<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Map1" tilewidth="64" tileheight="64">
 <image source="Map1.png" trans="000000" width="256" height="960"/>
 <tile id="31">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
</tileset>
