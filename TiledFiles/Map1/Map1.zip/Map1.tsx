<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Map1" tilewidth="40" tileheight="40">
 <image source="Map1.png" trans="000000" width="200" height="600"/>
 <tile id="31">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="actor" value="EnemyDude"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="actor" value="EnemyDudeMelee"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="actor" value="NPCSimple"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="actor" value="QuestGiver"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="actor" value="PoliceMelee"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="actor" value="Police"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="box" value="1"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="exit" value="1"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="exit" value="2"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="exit" value="3"/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="exit" value="4"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="spID" value="1"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="spID" value="2"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="spID" value="3"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="startPointID" value="1"/>
   <property name="transport" value="2"/>
   <property name="transportTarget" value="2"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="startPointID" value="2"/>
   <property name="transport" value="4"/>
   <property name="transportTarget" value="2"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="startPointID" value="3"/>
   <property name="transport" value="1"/>
   <property name="transportTarget" value="2"/>
  </properties>
 </tile>
</tileset>
