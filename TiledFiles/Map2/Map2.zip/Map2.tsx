<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Map2" tilewidth="40" tileheight="40">
 <image source="Sheet_001.png" trans="000000" width="160" height="640"/>
 <tile id="15">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="Solid" value="1"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="actor" value="EnemyDude"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="actor" value="EnemyDudeMelee"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="actor" value="NPCSimple"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="actor" value="QuestGiver"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="actor" value="PoliceMelee"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="actor" value="Police"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="box" value="1"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="exit" value="1"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="exit" value="2"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="exit" value="3"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="exit" value="4"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="spID" value="1"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="startPointID" value="1"/>
   <property name="transport" value="1"/>
   <property name="transportTarget" value="1"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="startPointID" value="2"/>
   <property name="transport" value="2"/>
   <property name="transportTarget" value="1"/>
  </properties>
 </tile>
</tileset>
