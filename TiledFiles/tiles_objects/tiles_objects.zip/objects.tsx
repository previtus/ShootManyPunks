<?xml version="1.0" encoding="UTF-8"?>
<tileset name="objects" tilewidth="40" tileheight="40">
 <image source="Clipboard.png" trans="ffffff" width="160" height="120"/>
 <tile id="0">
  <properties>
   <property name="box" value="1"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="exit" value="1"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="exit" value="2"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="exit" value="3"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="exit" value="4"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="spID" value=""/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="startPointID" value=""/>
   <property name="transport" value="1"/>
   <property name="transportTarget" value=""/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="startPointID" value=""/>
   <property name="transport" value="2"/>
   <property name="transportTarget" value=""/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="startPointID" value=""/>
   <property name="transport" value="3"/>
   <property name="transportTarget" value=""/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="startPointID" value=""/>
   <property name="transport" value="4"/>
   <property name="transportTarget" value=""/>
  </properties>
 </tile>
</tileset>
