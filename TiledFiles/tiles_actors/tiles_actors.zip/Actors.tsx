<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Actors" tilewidth="40" tileheight="40">
 <image source="actors.png" trans="ffffff" width="160" height="40"/>
 <tile id="0">
  <properties>
   <property name="actor" value="EnemyDude"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="actor" value="EnemyDudeMelee"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="actor" value="QuestGiver"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="actor" value="npc_simple"/>
  </properties>
 </tile>
</tileset>
